export interface NewsItem {
  id: number;
  image: string;
  headline: string;
  content: string;
}